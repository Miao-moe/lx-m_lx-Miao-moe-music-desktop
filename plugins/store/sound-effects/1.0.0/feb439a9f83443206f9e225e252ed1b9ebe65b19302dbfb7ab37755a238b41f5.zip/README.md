# sound-effects 1.0.0

这是使用 LX-M 插件开发工具包统一打包的源码插件，可独立编辑和重新打包。

在支持源码插件的 LX-M 中打开「设置 → 插件商店 → 导入插件」，选择本 ZIP。软件使用内置编译器离线编译并加载，安装使用者无需另装 Node.js。

修改与打包方法见 DEVELOPMENT.md；使用独立工具包的 node lx-plugin.cjs pack <目录> <输出.zip>，不需要主程序仓库。

源码在 src/，辅助源码在 sdk/，锁定的离线依赖在 vendor/。请保留 LICENSE、NOTICE 和第三方依赖许可证。
导出时保留源码，个人设置单独保存在本机。
