# audio-tag-editor 1.1.0

这是 LX-M 纯源码插件包，不含 renderer.js、lyric.js 或预编译引擎。

在支持源码插件的 LX-M 中打开「设置 → 插件商店 → 导入插件」，选择本 ZIP。软件使用内置编译器编译 Vue/TypeScript、样式和浏览器引擎，成功后立即加载，无需另装 Node.js。

- plugin.json：版本、接口、源码入口、资源和文件校验清单。
- src/：插件源码和原始资源。
- sdk/：此插件使用的宿主组件源码；播放器等接口由运行中的软件提供。
- vendor/：锁定版本的第三方依赖代码和许可证，支持离线编译。

修改源码后，使用 LX-M 仓库的 node build-config/plugins/pack-source.cjs <目录> <输出.zip> 重新生成校验清单和 ZIP，再导入。
导出返回导入的源码包，个人设置单独保存在本机。
